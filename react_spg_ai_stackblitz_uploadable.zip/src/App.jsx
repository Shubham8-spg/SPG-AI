import React from 'react';

function App() {
  return (
    <div style={{ padding: 20, fontSize: 24 }}>
      <h1>SPG AI is Live on StackBlitz!</h1>
    </div>
  );
}

export default App;
