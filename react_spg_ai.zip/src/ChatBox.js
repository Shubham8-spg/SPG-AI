import React, { useState } from "react";

function ChatBox() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);

  async function handleSend() {
    if (!input.trim()) return;

    const newMessage = { role: "user", content: input };
    setMessages([...messages, newMessage]);
    setInput("");

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer YOUR_OPENAI_API_KEY"
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [...messages, newMessage]
      })
    });
    const data = await response.json();
    const botReply = data.choices[0].message;

    setMessages([...messages, newMessage, botReply]);
  }

  return (
    <div className="chatbox">
      <div className="messages">
        {messages.map((msg, i) => (
          <div key={i} className={msg.role}>
            <span>{msg.role === "user" ? "🧑‍💻" : "🤖"} {msg.content}</span>
          </div>
        ))}
      </div>
      <div className="input-box">
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Type your message..." />
        <button onClick={handleSend}>Send</button>
      </div>
    </div>
  );
}

export default ChatBox;