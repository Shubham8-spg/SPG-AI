import React, { useState } from "react";
import ChatBox from "./ChatBox";
import "./style.css";

function App() {
  const [darkMode, setDarkMode] = useState(true);
  return (
    <div className={darkMode ? "app dark" : "app light"}>
      <header>
        <h1>🤖 SPG AI</h1>
        <p>Founder: Shubham Pratap Gambhire</p>
        <button onClick={() => setDarkMode(!darkMode)}>
          Toggle {darkMode ? "Light" : "Dark"} Mode
        </button>
      </header>
      <ChatBox />
    </div>
  );
}

export default App;