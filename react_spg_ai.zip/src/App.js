import React from "react";

function App() {
  return (
    <div style={{ fontFamily: 'Arial', padding: 20 }}>
      <h1>Welcome to SPG AI</h1>
      <p>This is your AI Assistant built with React and OpenAI.</p>
    </div>
  );
}

export default App;